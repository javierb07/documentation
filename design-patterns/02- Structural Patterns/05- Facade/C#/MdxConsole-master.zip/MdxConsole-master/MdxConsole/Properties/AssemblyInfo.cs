using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MdxConsole")]
[assembly: AssemblyDescription("Managed DirectX Console Library")]
[assembly: AssemblyConfiguration("Default")]
[assembly: AssemblyCompany("Dmitri Nesteruk")]
[assembly: AssemblyProduct("MdxConsole")]
[assembly: AssemblyCopyright("Copyright � 2008 Dmitri Nesteruk")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(true)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("45a919bb-9d01-4816-80d3-048ba61294a3")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
